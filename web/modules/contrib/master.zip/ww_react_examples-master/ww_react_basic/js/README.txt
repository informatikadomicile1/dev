# Example react app using Laravel-mix.

To create this project yourself, run the following:

`npm install react react-dom -s`

`npm install laravel-mix cross-env --save-dev`
