import React from "react";

const Page = () => (
  <div>
    <p><strong>React</strong> loaded using Laravel Mix</p>
  </div>
);

export default Page;
