# Example react app using Laravel-mix

To create this project yourself, run the following:

`npm install react react-dom -s`

`npm install laravel-mix cross-env --save-dev`

To test this module:
- Add this module into your Drupal site.
- Add the "React basic block" into a region.
- Go into `js` and compile the JavaScript: `npm run dev`

Read the full tutorial over at https://www.webwash.net/?p=11702
